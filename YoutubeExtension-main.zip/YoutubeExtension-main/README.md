**How to use this Extension.**
1. Download Zip file 
2. Unzip/Extract that file.
3. Go to Chrome => Click on three dots => Extansions => Manage Extensions => Unable Developer Mode => Load Unpacked => select that Unzip/Extract  stuff.
